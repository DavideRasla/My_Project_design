Visual Studio 2008 solution and Visual C++ 9 project files 
to build the CUnit library, example programs, and test program.