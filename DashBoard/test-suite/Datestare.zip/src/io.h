
#ifndef IO_H
#define IO_H

#include "types.h"
#include "Event.h"

void io_init();

bool_t Button_LeftArrow_Read();

void get_buttons_events();



#endif
